-- 2. Birth year of Emma Stone
SELECT birth FROM people WHERE name = 'Emma Stone';
