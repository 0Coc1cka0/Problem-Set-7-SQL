-- Keep a log of any SQL queries you execute as you solve the mystery.

-- 1. Отчёт о краже 28 июля 2025 года на Humphrey Street
SELECT description FROM crime_scene_reports
WHERE year = 2025 AND month = 7 AND day = 28 AND street = 'Humphrey Street';

-- 2. Показания трёх свидетелей за этот день
SELECT name, transcript FROM interviews
WHERE year = 2025 AND month = 7 AND day = 28 AND transcript LIKE '%bakery%';

-- 3. Камеры на парковке пекарни (10:15 - 10:25)
SELECT license_plate, activity, minute FROM bakery_security_logs
WHERE year = 2025 AND month = 7 AND day = 28 AND hour = 10 AND minute BETWEEN 15 AND 25;

-- 4. Снятие денег в банкомате на Leggett Street утром 28 июля
SELECT account_number, amount FROM atm_transactions
WHERE year = 2025 AND month = 7 AND day = 28 AND atm_location = 'Leggett Street' AND transaction_type = 'withdraw';

-- 5. Короткие звонки (< 60 секунд) 28 июля
SELECT caller, receiver, duration FROM phone_calls
WHERE year = 2025 AND month = 7 AND day = 28 AND duration < 60;

-- 6. Самый ранний рейс из Fiftyville на 29 июля 2025 года и город назначения
SELECT flights.id, airports.city, flights.hour, flights.minute FROM flights
JOIN airports ON flights.destination_airport_id = airports.id
WHERE flights.origin_airport_id = (SELECT id FROM airports WHERE city = 'Fiftyville')
AND flights.year = 2025 AND flights.month = 7 AND flights.day = 29
ORDER BY flights.hour, flights.minute LIMIT 1;

-- 7. Вор, сопоставив машину, банковский счёт, звонок и билет на первый рейс (id рейса = 36)
SELECT people.name FROM people
JOIN bank_accounts ON people.id = bank_accounts.person_id
JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
JOIN bakery_security_logs ON people.license_plate = bakery_security_logs.license_plate
JOIN phone_calls ON people.phone_number = phone_calls.caller
JOIN passengers ON people.passport_number = passengers.passport_number
WHERE atm_transactions.year = 2025 AND atm_transactions.month = 7 AND atm_transactions.day = 28
AND atm_transactions.atm_location = 'Leggett Street' AND atm_transactions.transaction_type = 'withdraw'
AND bakery_security_logs.year = 2025 AND bakery_security_logs.month = 7 AND bakery_security_logs.day = 28
AND bakery_security_logs.hour = 10 AND bakery_security_logs.minute BETWEEN 15 AND 25
AND phone_calls.year = 2025 AND phone_calls.month = 7 AND phone_calls.day = 28 AND phone_calls.duration < 60
AND passengers.flight_id = 36;

-- 8. Сообщник, которому звонил Bruce
SELECT people.name FROM people
JOIN phone_calls ON people.phone_number = phone_calls.receiver
WHERE phone_calls.caller = (SELECT phone_number FROM people WHERE name = 'Bruce')
AND phone_calls.year = 2025 AND phone_calls.month = 7 AND phone_calls.day = 28 AND phone_calls.duration < 60;

